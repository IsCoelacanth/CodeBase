#include <bits/stdc++.h>
using namespace std;

int main()
{
	printf("Hello World !\n");
  for(int i = 0 ; i < 10 ;i++)
    printf("%d is a number",i);
  printf("Byeeee");
	return 0;
}
